# Frequently Asked Questions
v2.1.84
Revised Tue Aug 14 15:42:38 EDT 2018

## What if none of these answers solve my problem?

No problem. Post a new "issue" on the [GitHub issue tracker](https://github.com/hartleys/QoRTs/issues). 
This is the preferred way to contact me, since it may help others solve similar problems.

If possible, attach the logs from vArmyKnife and include with the "--verbose" option to maximize the debugging information.

